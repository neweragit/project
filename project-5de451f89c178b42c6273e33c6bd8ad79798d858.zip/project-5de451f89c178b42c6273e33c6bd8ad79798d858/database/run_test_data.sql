-- Run this script to insert test data
-- Make sure to run this in your Supabase SQL editor or database client

-- First, let's clear existing test data (optional - be careful in production!)
-- DELETE FROM event_tickets;
-- DELETE FROM contact_messages;
-- DELETE FROM events;
-- DELETE FROM users;
-- DELETE FROM accounts;
-- DELETE FROM field_of_interest_options;
-- DELETE FROM admin_actions;

-- Then run the insert_test_data.sql file
-- Or copy and paste the content from insert_test_data.sql here 